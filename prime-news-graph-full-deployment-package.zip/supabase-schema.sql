-- ==============================================================================
-- PRIME NEWS GRAPH — Enterprise PostgreSQL & Supabase Database Migration
-- Version: 1.0.0
-- Architecture: Row Level Security (RLS), Role Based Access Control (RBAC)
-- ==============================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Authors Table
CREATE TABLE IF NOT EXISTS public.authors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    bio_bn TEXT,
    bio_en TEXT,
    avatar TEXT,
    email TEXT UNIQUE,
    role TEXT DEFAULT 'Contributor',
    social_twitter TEXT,
    social_facebook TEXT,
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 3. News Categories Table
CREATE TABLE IF NOT EXISTS public.news_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug TEXT UNIQUE NOT NULL,
    name_bn TEXT NOT NULL,
    name_en TEXT NOT NULL,
    color TEXT DEFAULT '#246BFD',
    order_index INTEGER DEFAULT 0,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 4. News Articles Table
CREATE TABLE IF NOT EXISTS public.news_articles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug TEXT UNIQUE NOT NULL,
    title_bn TEXT NOT NULL,
    title_en TEXT NOT NULL,
    summary_bn TEXT,
    summary_en TEXT,
    content_bn TEXT NOT NULL,
    content_en TEXT,
    category_id UUID REFERENCES public.news_categories(id) ON DELETE SET NULL,
    category_slug TEXT NOT NULL,
    author_id UUID REFERENCES public.authors(id) ON DELETE SET NULL,
    author_name TEXT NOT NULL,
    author_avatar TEXT,
    featured_image TEXT NOT NULL,
    image_caption_bn TEXT,
    image_caption_en TEXT,
    gallery_images TEXT[] DEFAULT '{}',
    video_url TEXT,
    status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft', 'archived', 'scheduled')),
    is_featured BOOLEAN DEFAULT false,
    is_editors_choice BOOLEAN DEFAULT false,
    views_count BIGINT DEFAULT 0,
    published_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL,
    seo_title TEXT,
    seo_description TEXT,
    reading_time_minutes INTEGER DEFAULT 4,
    tags TEXT[] DEFAULT '{}'
);

-- 5. Breaking News Table
CREATE TABLE IF NOT EXISTS public.breaking_news (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_bn TEXT NOT NULL,
    title_en TEXT NOT NULL,
    target_url TEXT DEFAULT '/',
    priority INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    label_bn TEXT DEFAULT 'ব্রেকিং নিউজ',
    label_en TEXT DEFAULT 'BREAKING NEWS',
    scroll_speed INTEGER DEFAULT 35,
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 6. Advertisements Table (Adsterra & Display Ads)
CREATE TABLE IF NOT EXISTS public.advertisements (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    format TEXT DEFAULT 'banner' CHECK (format IN ('banner', 'popunder', 'social_bar', 'native')),
    ad_code TEXT NOT NULL,
    banner_image_url TEXT,
    banner_target_link TEXT,
    is_active BOOLEAN DEFAULT true,
    device_target TEXT DEFAULT 'all' CHECK (device_target IN ('all', 'desktop', 'mobile')),
    impressions BIGINT DEFAULT 0,
    clicks BIGINT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 7. Comments Table
CREATE TABLE IF NOT EXISTS public.comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    article_id UUID REFERENCES public.news_articles(id) ON DELETE CASCADE,
    article_title TEXT,
    author_name TEXT NOT NULL,
    author_email TEXT NOT NULL,
    content TEXT NOT NULL,
    status TEXT DEFAULT 'approved' CHECK (status IN ('approved', 'pending', 'spam')),
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 8. Newsletter Subscribers Table
CREATE TABLE IF NOT EXISTS public.newsletter_subscribers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'unsubscribed')),
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 9. Videos Table
CREATE TABLE IF NOT EXISTS public.videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_bn TEXT NOT NULL,
    title_en TEXT,
    youtube_id TEXT NOT NULL,
    category TEXT DEFAULT 'national',
    is_featured BOOLEAN DEFAULT false,
    published_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 10. Website Settings
CREATE TABLE IF NOT EXISTS public.website_settings (
    id TEXT PRIMARY KEY DEFAULT 'global',
    site_name TEXT DEFAULT 'PRIME NEWS GRAPH',
    site_tagline_bn TEXT,
    site_tagline_en TEXT,
    logo_text TEXT DEFAULT 'PRIME NEWS GRAPH',
    default_language TEXT DEFAULT 'bn',
    contact_email TEXT,
    contact_phone TEXT,
    contact_address TEXT,
    copyright_text TEXT,
    facebook_url TEXT,
    twitter_url TEXT,
    youtube_url TEXT,
    instagram_url TEXT,
    whatsapp_number TEXT,
    telegram_url TEXT,
    homepage_sections JSONB DEFAULT '{"hero": true, "breaking": true, "latest": true, "popular": true, "categories": true, "editors_choice": true, "videos": true, "newsletter": true}'::jsonb,
    updated_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 11. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_articles_slug ON public.news_articles (slug);
CREATE INDEX IF NOT EXISTS idx_articles_status_published ON public.news_articles (status, published_at DESC);
CREATE INDEX IF NOT EXISTS idx_articles_category ON public.news_articles (category_slug);
CREATE INDEX IF NOT EXISTS idx_breaking_active ON public.breaking_news (is_active, priority ASC);
CREATE INDEX IF NOT EXISTS idx_comments_article ON public.comments (article_id, status);

-- 12. Row Level Security (RLS) Configuration
ALTER TABLE public.news_articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.news_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.breaking_news ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.advertisements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.newsletter_subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_settings ENABLE ROW LEVEL SECURITY;

-- Public Read Policies
CREATE POLICY "Public articles are readable by everyone" ON public.news_articles FOR SELECT USING (status = 'published');
CREATE POLICY "Public categories are readable by everyone" ON public.news_categories FOR SELECT USING (true);
CREATE POLICY "Public breaking news is readable by everyone" ON public.breaking_news FOR SELECT USING (is_active = true);
CREATE POLICY "Active ads are readable by everyone" ON public.advertisements FOR SELECT USING (is_active = true);
CREATE POLICY "Approved comments are readable by everyone" ON public.comments FOR SELECT USING (status = 'approved');
CREATE POLICY "Settings readable by everyone" ON public.website_settings FOR SELECT USING (true);
CREATE POLICY "Public can add comment" ON public.comments FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can subscribe to newsletter" ON public.newsletter_subscribers FOR INSERT WITH CHECK (true);

-- Authenticated Admin Policies
CREATE POLICY "Admins full access to articles" ON public.news_articles FOR ALL TO authenticated USING (true);
CREATE POLICY "Admins full access to categories" ON public.news_categories FOR ALL TO authenticated USING (true);
CREATE POLICY "Admins full access to breaking news" ON public.breaking_news FOR ALL TO authenticated USING (true);
CREATE POLICY "Admins full access to ads" ON public.advertisements FOR ALL TO authenticated USING (true);
CREATE POLICY "Admins full access to comments" ON public.comments FOR ALL TO authenticated USING (true);
CREATE POLICY "Admins full access to subscribers" ON public.newsletter_subscribers FOR ALL TO authenticated USING (true);
CREATE POLICY "Admins full access to settings" ON public.website_settings FOR ALL TO authenticated USING (true);
